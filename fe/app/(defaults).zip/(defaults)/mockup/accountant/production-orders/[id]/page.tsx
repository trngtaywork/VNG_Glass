'use client';
import React from 'react';
import ProductionOrdersDetailAccountantComponent from '@/components/VNG/accountant/production-orders-detail-accountant-component';

const CreateProductionOrderPage = () => {
  

    return (
        <div>
            <ProductionOrdersDetailAccountantComponent 
            />
        </div>
    );
};

export default CreateProductionOrderPage;