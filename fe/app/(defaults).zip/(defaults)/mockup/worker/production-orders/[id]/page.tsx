'use client';
import React from 'react';
import ProductionOrdersDetailWorkerComponent from '@/components/VNG/worker/production-orders-detail-worker-component';

const CreateProductionOrderPage = () => {
  

    return (
        <div>

            
            <ProductionOrdersDetailWorkerComponent 
                
            />
        </div>
    );
};

export default CreateProductionOrderPage;