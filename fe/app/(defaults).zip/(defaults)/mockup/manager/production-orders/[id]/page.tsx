'use client';
import React from 'react';
import ProductionOrdersDetailManagerComponent from '@/components/VNG/manager/production-orders-detail-manager-component';

const CreateProductionOrderPage = () => {
  

    return (
        <div>
            <ProductionOrdersDetailManagerComponent 
            />
        </div>
    );
};

export default CreateProductionOrderPage;